import { useEffect, useState } from "react";
import { api } from "./App";



export function OwnerPanel() {
    const [stores, setStores] = useState([]);
    const [ratings, setRatings] = useState({});


    useEffect(() => { load(); }, []);
    async function load() { 
        try { 
            const s = await api('/api/owner/stores'); 
            setStores(s); 
            for (const st of s) { 
                const r = await api(`/api/owner/stores/${st.id}/ratings`); 
                setRatings(prev => ({ ...prev, [st.id]: r })); 
            } 
        } catch (e) { console.error(e); } 
    }


    return (
        <section className="container admin">
            <h2>Owner dashboard</h2>
            <div className="grid">
                {stores.map(s => (
                    <div className="card" key={s.id}>
                        <h3>{s.name} <span className="muted">{s.rating ? Number(s.rating).toFixed(1) : '0.0'}</span></h3>
                        <div className="muted">{s.address}</div>
                        <h4>Ratings</h4>
                        <div className="ratings-list">
                            {(ratings[s.id] || []).map(r => (
                                <div key={r.id} className="rating-row"><strong>{r.user_name}</strong> — {r.rating} <span className="muted">({new Date(r.updated_at).toLocaleString()})</span></div>
                            ))}
                            {(ratings[s.id] || []).length === 0 && <div className="muted">No ratings yet</div>}
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
}
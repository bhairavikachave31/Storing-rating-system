import { useState } from "react";
import { API } from "./App";
import axios from "axios";


export function Auth({ onAuth }) {
    const [mode, setMode] = useState('login'); // login | signup
    const [form, setForm] = useState({ name: '', email: '', password: '', role: '' });
    const [err, setErr] = useState(null);


    async function submit(e) {
        e.preventDefault(); setErr(null);
        try {
            if (mode === 'login') {
                const res = await axios.post(API + '/api/auth/login', { email: form.email, password: form.password }, {headers: { 'Content-Type': 'application/json' }});
                if(res.data.status){
                    onAuth(res.data.token);
                }
            } else {
                const res = await axios.post(API + '/api/auth/signup', form, { headers: { 'Content-Type': 'application/json ' }});
                if(res.data.status){
                    onAuth(res.data.token);
                }
            }
        } catch (e) { setErr(e.message || JSON.stringify(e)); }
    }
    return (
        <section className="auth">
            <div className="card">
                <h2>{mode === 'login' ? 'Login' : 'Sign up'}</h2>
                <form onSubmit={submit}>
                    {mode === 'signup' && (
                        <label>
                            Name
                            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
                        </label>
                    )}
                    <label>
                        Email
                        <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
                    </label>
                    <label>
                        Password
                        <input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required />
                    </label>
                    {mode === 'signup' && (
                        <label>
                            Role
                            <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
                                <option value="USER">User</option>
                                <option value="OWNER">Owner</option>
                            </select>
                        </label>
                    )}
                    <div className="actions">
                        <button type="submit" className="btn">{mode === 'login' ? 'Login' : 'Create account'}</button>
                        <button type="button" className="btn-ghost" onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setErr(null); }}>Switch to {mode === 'login' ? 'Sign up' : 'Login'}</button>
                    </div>
                    {err && <div className="error">{err}</div>}
                </form>
            </div>
        </section>
    );
}
import { useState, useEffect } from 'react';
// import './App.css'
import './style.css';
import { Header } from './Header';
import { Auth } from './Auth';
import { AdminPanel } from './AdminPanel';
import { OwnerPanel } from './OwnerPanel';
import { StoreList } from './Store';

export const API = "http://localhost:5000";

function saveToken(token) { localStorage.setItem('token', token); }
function getToken() { return localStorage.getItem('token'); }
function clearToken() { localStorage.removeItem('token'); }

export async function api(path, method = 'GET', body) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API + path, opts);
  const txt = await res.text();
  try {
    const json = JSON.parse(txt);
    if (!res.ok) throw json; return json;
  } catch (e) { if (res.ok) return txt; throw e; }
}

function App() {
  const [me, setMe] = useState(null);
  const [view, setView] = useState('stores'); // stores | admin | owner


  useEffect(() => { if (getToken()) loadMe(); }, []);


  async function loadMe() {
    try {
      const data = await api('/api/me');
      setMe(data);
      if (data.role === 'ADMIN') setView('admin');
      if (data.role === 'OWNER') setView('owner');
    } catch (e) {
      console.log('me err', e);
      clearToken(); setMe(null);
    }
  }


  function handleLogout() { clearToken(); setMe(null); setView('stores'); }


  return (
    <div className="app-root">
      <Header me={me} onLogout={handleLogout} onSetView={setView} view={view} />
      <main>
        {!me ? (
          <Auth onAuth={async (token) => { saveToken(token); await loadMe(); }} />
        ) : (
          <>
            {view === 'stores' && <StoreList me={me} />}
            {view === 'admin' && me?.role === 'ADMIN' && <AdminPanel />}
            {view === 'owner' && me?.role === 'OWNER' && <OwnerPanel />}
            {me?.role === 'USER' && view === 'stores' && <p className="hint">Tip: As a USER you can rate stores in the list above.</p>}
          </>
        )}
      </main>

    </div>
  );
}

export default App;

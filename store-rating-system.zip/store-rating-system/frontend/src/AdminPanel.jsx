import { useEffect, useState } from "react";
import { api } from "./App";


export function AdminPanel() {
    const [users, setUsers] = useState([]);
    const [stores, setStores] = useState([]);
    const [loading, setLoading] = useState(false);
    const [newStore, setNewStore] = useState({ name: '', address: '', email: '', owner_id: '' });


    useEffect(() => { loadAll(); }, []);

    async function loadAll() { 
        setLoading(true); 
        try { 
            const u = await api('/api/admin/users');
            const s = await api('/api/admin/stores');
            console.log('users',u.result);
            setUsers(u.result);
            setStores(s.result);
        } catch (e) {
            console.error(e)
        } finally{
            setLoading(false);
        }
    }


    async function createStore(e) { 
        e.preventDefault(); 
        try { 
            await api('/api/admin/stores', 'POST', { name: newStore.name, address: newStore.address, email: newStore.email, owner_id: newStore.owner_id || null }); 
            setNewStore({ name: '', address: '', email: '', owner_id: '' }); 
            loadAll();
        } catch (e) { alert(e.message || 'err'); } }


    async function delStore(id) { 
        if (!window.confirm('Delete store?')) return; 
        await api(`/api/admin/stores/${id}`, 'DELETE'); 
        loadAll(); 
    }


    return (
        <section className="container admin">
            <h2>Admin — Manage Users & Stores</h2>
            {loading ? <p>Loading…</p> : (
                <>
                    <div className="flex-grid">
                        <div className="card table">
                            <h3>Users</h3>
                            <table>
                                <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr></thead>
                                <tbody>{users.length && users?.map(u => <tr key={u.id}><td>{u.id}</td><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td></tr>)}</tbody>
                            </table>
                        </div>
                        <div className="card table">
                            <h3>Stores</h3>
                            <table>
                                <thead><tr><th>ID</th><th>Name</th><th>Address</th><th>Owner</th><th></th></tr></thead>
                                <tbody>{stores.map(s => <tr key={s.id}><td>{s.id}</td><td>{s.name}</td><td>{s.address}</td><td>{s.owner_name || '-'}</td><td><button className="btn-ghost small" onClick={() => delStore(s.id)}>Delete</button></td></tr>)}</tbody>
                            </table>
                        </div>
                    </div>


                    <div className="card">
                        <h3>Create store</h3>
                        <form onSubmit={createStore} className="form-row">
                            <label>Name<input required value={newStore.name} onChange={e => setNewStore({ ...newStore, name: e.target.value })} /></label>
                            <label>Address<input required value={newStore.address} onChange={e => setNewStore({ ...newStore, address: e.target.value })} /></label>
                            <label>Owner ID (optional)<input value={newStore.owner_id} onChange={e => setNewStore({ ...newStore, owner_id: e.target.value })} /></label>
                            <div className="actions"><button className="btn" type="submit">Create</button></div>
                        </form>
                    </div>
                </>
            )}
        </section>
    );
}
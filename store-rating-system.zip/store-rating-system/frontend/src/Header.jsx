

export function Header({ me, onLogout, onSetView, view }) {
    return (
        <header className="topbar">
            <div className="brand">Store Ratings</div>
            <nav>
                <button className={`btn-ghost ${view === 'stores' ? 'active' : ''}`} onClick={() => onSetView('stores')}>Stores</button>
                {me?.role === 'ADMIN' && <button className={`btn-ghost ${view === 'admin' ? 'active' : ''}`} onClick={() => onSetView('admin')}>Admin</button>}
                {me?.role === 'OWNER' && <button className={`btn-ghost ${view === 'owner' ? 'active' : ''}`} onClick={() => onSetView('owner')}>Owner</button>}
            </nav>
            <div className="user-area">
                {me ? (
                    <>
                        <span className="who">{me.name} <small>({me.role})</small></span>
                        <button className="btn-ghost" onClick={onLogout}>Logout</button>
                    </>
                ) : <span className="who">Not signed in</span>}
            </div>
        </header>
    );
}
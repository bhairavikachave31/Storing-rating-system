import { useEffect, useState } from "react";
import { api } from "./App";
import StarGroup from './StarGroup';


function StoreCard({ store, me, onUpdate }) {
    const [rating, setRating] = useState(0);
    const [myRating, setMyRating] = useState(null);
    const [loading, setLoading] = useState(false);


    useEffect(() => { 
        setRating(parseFloat(store.rating || 0)); 
        if (me?.role === 'USER') {
            fetchMyRating(); 
        }
    }, [store, me]);


    async function fetchMyRating() {
        try {
            const res = await api('/api/ratings/mine');
            const found = res.find(r => r.store_id === store.id);
            if (found) setMyRating(found);
        } catch (e) {  }
    }


    async function submit(r) {
        if (me?.role !== 'USER') { alert('Only USER can rate. Sign up as USER.'); return; }
        setLoading(true);
        try {
            const body = { store_id: store.id, rating: r };
            const res = await api('/api/ratings', 'POST', body);
            setRating(res.average);
            setMyRating({ id: res.id, rating: r });
            if (onUpdate) onUpdate();
        } catch (e) { alert(e.message || 'Could not submit rating'); }
        setLoading(false);
    }


    return (
        <div className="card store">
            <div className="store-head">
                <div>
                    <h3>{store.name}</h3>
                    <div className="muted">{store.address} {store.owner_name ? ` • owner: ${store.owner_name}` : ''}</div>
                </div>
                <div className="avg">{rating ? Number(rating).toFixed(1) : '0.0'}</div>
            </div>


            <div className="stars">
                <StarGroup value={myRating?.rating || 0} onChange={(v) => submit(v)} disabled={loading} />
            </div>
        </div>
    );
}

export function StoreList({ me }) {
    const [stores, setStores] = useState([]);
    const [q, setQ] = useState('');
    const [sort, setSort] = useState('rating_desc');
    const [loading, setLoading] = useState(false);


    useEffect(() => {
        const delay = setTimeout(()=>{
            load(); 
        },1000);

        return()=>{
            clearTimeout(delay);
        }
    }, [q, sort]);

    async function load() {
        setLoading(true);
        try { 
            const data = await api(`/api/stores?search=${encodeURIComponent(q)}&sort=${sort}`);
            console.log('store data',data);
            setStores(data); 
        } catch (e) { 
            console.error(e) 
        } finally{
            setLoading(false);
        }
    }


    return (
        <section className="container">
            <div className="toolbar flex-grid">
                <input placeholder="Search stores" value={q} onChange={e => setQ(e.target.value)} />
                <select value={sort} onChange={e => setSort(e.target.value)}>
                    <option value="rating_desc">Top rated</option>
                    <option value="rating_asc">Lowest rated</option>
                    <option value="name_asc">Name A→Z</option>
                    <option value="name_desc">Name Z→A</option>
                </select>
            </div>


            {loading ? <p>Loading…</p> : (
                <div className="grid">
                    {stores.map(s => (
                        <StoreCard key={s.id} store={s} me={me} onUpdate={() => {api('/api/stores').then(load).catch(() => { }); load(); }} />
                    ))}
                    {stores.length === 0 && <p className="muted">No stores found.</p>}
                </div>
            )}
        </section>
    );
}


import { useState } from "react";



export  default function StarGroup({ value = 0, onChange, disabled }) {
  console.log('value',value);
  const [hover, setHover] = useState(0);
  return (
    <div className={`star-group ${disabled ? 'disabled' : ''}`}>
      {[1, 2, 3, 4, 5].map(i => (
        <button key={i} className={`star ${i <= (hover || value) ? 'filled' : ''}`} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(0)} onClick={() => onChange(i)} disabled={disabled} aria-label={`Rate ${i}`}>
          ★
        </button>
      ))}
    </div>
  );
}
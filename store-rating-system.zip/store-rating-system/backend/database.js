const { Client } = require('pg');

async function main() {
  // Configure your PostgreSQL connection
  // const client = new Client({
  //   host: process.env.HOST,
  //   user: process.env.DBUSER,
  //   password: process.env.PASSWORD,
  //   database: process.env.DATABASE,
  //   port: process.env.PORT
  // });
  const client = new Client({
    host: 'localhost',
    user: 'postgres',
    password: 'Tushar@2001',
    database: 'store_ratings',
    port: '5432'
  });

  try {
    await client.connect();
    console.log('Connected to PostgreSQL ✅');

    // Queries to create enum type and tables
    const queries = `
     DO $$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'role_enum') THEN
          CREATE TYPE role_enum AS ENUM ('ADMIN','USER','OWNER');
        END IF;
      END $$;

      -- Users table
      CREATE TABLE IF NOT EXISTS users (
        id          SERIAL PRIMARY KEY,
        name        VARCHAR(60) NOT NULL,
        email       VARCHAR(100) UNIQUE NOT NULL,
        password    VARCHAR(255) NOT NULL,
        address     VARCHAR(400),
        role        role_enum DEFAULT 'USER' NOT NULL
      );

      -- 3) Stores
      CREATE TABLE IF NOT EXISTS stores (
        id          SERIAL PRIMARY KEY,
        name        VARCHAR(100) NOT NULL,
        email       VARCHAR(100),
        address     VARCHAR(400) NOT NULL,
        rating      NUMERIC(3,2) DEFAULT 0,
        owner_id    INT REFERENCES users(id) ON DELETE SET NULL
      );

      -- 4) Ratings
      CREATE TABLE IF NOT EXISTS ratings (
        id          SERIAL PRIMARY KEY,
        user_id     INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        store_id    INT NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
        rating      INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
        created_at  TIMESTAMP DEFAULT NOW(),
        updated_at  TIMESTAMP DEFAULT NOW(),
        CONSTRAINT uq_user_store UNIQUE (user_id, store_id)
      );
    `;

    await client.query(queries);
    console.log('Tables created successfully 🎉');
  } catch (err) {
    console.error('Error executing query:', err);
  } finally {
    await client.end();
    console.log('Connection closed 🚪');
  }
}

main();

const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const jwt = require('jsonwebtoken');
const bcrypt = require("bcrypt");
const { Client } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());



const host = process.env.HOST;
const user = process.env.DBUSER;
const password = process.env.PASSWORD;
const database = process.env.DATABASE;
const port = process.env.PORT;

console.log(host, user, password, database, port);

const client = new Client({
    host: 'localhost',
    user: 'postgres',
    password: 'Tushar@2001',
    database: 'store_ratings',
    port: '5432'
});


const JWT_SECRET = process.env.JWT_SECRET || 'supersecret_change_me';

// ---- UTIL ----
const signToken = (user) =>
    jwt.sign(
        { id: user.id, role: user.role, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: '7d' }
    );


client.connect(err => {
    if (err) throw err;
    console.log("✅ DB Connected...");
});


const auth = async (req, res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ message: 'Missing token' });
    try {
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch (e) {
        return res.status(401).json({ message: 'Invalid token' });
    }
};

const requireRole = (...roles) => (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
        return res.status(403).json({ message: 'Forbidden' });
    }
    next();
};

async function updateStoreAverage(storeId) {
    const { rows } = await client.query(
        'SELECT AVG(rating)::numeric(10,2) AS avg FROM ratings WHERE store_id=$1',
        [storeId]
    );
    const avg = rows[0].avg || 0;
    await client.query('UPDATE stores SET rating=$1 WHERE id=$2', [avg, storeId]);
    return avg;
}

app.get("/", (req, res) => {
    res.send("Backend is running");
});

// AUTH 
// Signup: USER or OWNER
app.post('/api/auth/signup', async (req, res) => {
    try {
        const { name, email, password, address = '', role = 'USER' } = req.body;
        if (!name || !email || !password)
            return res.status(400).json({'status':false, message: 'name, email, password required' });

        if (!['USER', 'OWNER'].includes(role))
            return res.status(400).json({'status':false, message: 'role must be USER or OWNER' });

        const exists = await client.query('SELECT id FROM users WHERE email=$1', [email]);
        if (exists.rowCount) return res.status(400).json({'status':false, message: 'Email already in use' });

        const hash = await bcrypt.hash(password, 10);
        const ins = await client.query(
            'INSERT INTO users(name,email,password,address,role) VALUES ($1,$2,$3,$4,$5) RETURNING id,name,email,role',
            [name, email, hash, address, role]
        );
        const user = ins.rows[0];
        const token = signToken(user);
        res.status(201).json({'status':true, token, user });
    } catch (e) {
        console.error(e);
        res.status(500).json({'status':false, message: 'Signup failed' });
    }
});

// Login
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password)
            return res.status(400).json({ 'status':false, message: 'email and password required' });

        const q = await client.query('SELECT * FROM users WHERE email=$1', [email]);
        if (!q.rowCount) return res.status(401).json({ 'status':false, message: 'Invalid credentials' });
        const user = q.rows[0];
        const ok = await bcrypt.compare(password, user.password);
        if (!ok) return res.status(401).json({ 'status':false, message: 'Invalid credentials' });

        const token = signToken(user);
        res.json({ 'status':true,
            token,
            user: { id: user.id, name: user.name, email: user.email, role: user.role },
        });
    } catch (e) {
        console.error(e);
        res.status(500).json({ 'status':false, message: 'Login failed' });
    }
});

// user's details
app.get('/api/me', auth, async (req, res) => {
    const q = await client.query(
        'SELECT id,name,email,address,role FROM users WHERE id=$1',
        [req.user.id]
    );
    res.json(q.rows[0]);
});

// PUBLIC STORES 
app.get('/api/stores', async (req, res) => {
    const { search = '', sort = 'rating_desc' } = req.query;
    const allowed = {
        name_asc: 's.name ASC',
        name_desc: 's.name DESC',
        rating_asc: 's.rating ASC',
        rating_desc: 's.rating DESC',
    };
    const orderBy = allowed[sort] || allowed.rating_desc;
    const like = `%${search}%`;
    const q = await client.query(
        `SELECT s.id, s.name, s.email, s.address, s.rating, s.owner_id, u.name AS owner_name
     FROM stores s
     LEFT JOIN users u ON u.id = s.owner_id
     WHERE s.name ILIKE $1 OR s.address ILIKE $1
     ORDER BY ${orderBy}`,
        [like]
    );
    res.json(q.rows);
});

//  USER RATINGS 
app.get('/api/ratings/mine', auth, requireRole('USER'), async (req, res) => {
    const q = await client.query(
        `SELECT r.id, r.store_id, s.name AS store_name, r.rating, r.updated_at
            FROM ratings r
            JOIN stores s ON s.id=r.store_id
            WHERE r.user_id=$1
            ORDER BY r.updated_at DESC`,[req.user.id]
    );
    res.json(q.rows);
});

// Create/Update rating
app.post('/api/ratings', auth, requireRole('USER'), async (req, res) => {
    try {
        const { store_id, rating } = req.body;
        if (!store_id || !rating)
            return res.status(400).json({ message: 'store_id and rating required' });
        if (rating < 1 || rating > 5)
            return res.status(400).json({ message: 'rating must be 1-5' });

        // const client = await client.connect();
        try {
            await client.query('BEGIN');

            const result = await client.query(
                `INSERT INTO ratings (user_id, store_id, rating)
                    VALUES ($1,$2,$3)
                    ON CONFLICT (user_id, store_id)
                    DO UPDATE SET rating = EXCLUDED.rating, updated_at = NOW()
                    RETURNING id`,[req.user.id, store_id, rating]
            );
            const ratingId = result.rows[0].id;

            const avgQ = await client.query('SELECT AVG(rating)::numeric(10,2) AS avg FROM ratings WHERE store_id=$1',[store_id]);
            const avg = avgQ.rows[0].avg || 0;
            await client.query('UPDATE stores SET rating=$1 WHERE id=$2', [avg, store_id]);
            await client.query('COMMIT');
            res.status(201).json({ id: ratingId, store_id, rating, average: avg });
        } catch (e) {
            await client.query('ROLLBACK');
            throw e;
        } finally {
            // client.release();
        }
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: 'Could not submit rating' });
    }
});

// Update rating by id
app.put('/api/ratings/:id', auth, requireRole('USER'), async (req, res) => {
    try {
        const { rating } = req.body;
        const { id } = req.params;
        if (!rating) return res.status(400).json({ message: 'rating required' });

        const r = await client.query(
            'SELECT store_id FROM ratings WHERE id=$1 AND user_id=$2',
            [id, req.user.id]
        );
        if (!r.rowCount) return res.status(404).json({ message: 'Rating not found' });

        const storeId = r.rows[0].store_id;
        await client.query('UPDATE ratings SET rating=$1, updated_at=NOW() WHERE id=$2', [
            rating,
            id,
        ]);
        const avg = await updateStoreAverage(storeId);
        res.json({ id, rating, average: avg });
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: 'Could not update rating' });
    }
});

// ---- OWNER ----
// List stores owned by logged-in owner
app.get('/api/owner/stores', auth, requireRole('OWNER'), async (req, res) => {
    const q = await client.query(
        'SELECT id,name,email,address,rating FROM stores WHERE owner_id=$1 ORDER BY name ASC',
        [req.user.id]
    );
    res.json(q.rows);
});

// View ratings for a specific owned store
app.get(
    '/api/owner/stores/:id/ratings',
    auth,
    requireRole('OWNER'),
    async (req, res) => {
        const storeId = Number(req.params.id);
        // verify ownership
        const own = await client.query('SELECT id FROM stores WHERE id=$1 AND owner_id=$2', [
            storeId,
            req.user.id,
        ]);
        if (!own.rowCount) return res.status(403).json({ message: 'Not your store' });

        const q = await client.query(
            `SELECT r.id, r.rating, r.updated_at, u.id AS user_id, u.name AS user_name
       FROM ratings r
       JOIN users u ON u.id=r.user_id
       WHERE r.store_id=$1
       ORDER BY r.updated_at DESC`,
            [storeId]
        );
        res.json(q.rows);
    }
);

// Admin: list users
app.get('/api/admin/users', auth, requireRole('ADMIN'), async (req, res) => {
    const result = await client.query('SELECT id,name,email,address,role FROM users ORDER BY id DESC;');
    if(result.rows){
        res.status(200).json({
            'status':true,
            'result':result.rows
        })
    }
});

// Admin: create user (any role)
app.post('/api/admin/users', auth, requireRole('ADMIN'), async (req, res) => {
    try {
        const { name, email, password, address = '', role = 'USER' } = req.body;
        if (!name || !email || !password)
            return res.status(400).json({ message: 'name, email, password required' });
        if (!['ADMIN', 'USER', 'OWNER'].includes(role))
            return res.status(400).json({ message: 'invalid role' });

        const exists = await client.query('SELECT id FROM users WHERE email=$1', [email]);
        if (exists.rowCount) return res.status(409).json({ message: 'Email already in use' });

        const hash = await bcrypt.hash(password, 10);
        const ins = await client.query(
            'INSERT INTO users(name,email,password,address,role) VALUES ($1,$2,$3,$4,$5) RETURNING id,name,email,address,role',
            [name, email, hash, address, role]
        );
        res.status(201).json(ins.rows[0]);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: 'Create user failed' });
    }
});

// Admin: update user
app.put('/api/admin/users/:id', auth, requireRole('ADMIN'), async (req, res) => {
    try {
        const { name, email, address, role } = req.body;
        if (role && !['ADMIN', 'USER', 'OWNER'].includes(role))
            return res.status(400).json({ message: 'invalid role' });

        const q = await client.query('SELECT * FROM users WHERE id=$1', [req.params.id]);
        if (!q.rowCount) return res.status(404).json({ message: 'User not found' });

        const u = q.rows[0];
        const up = await client.query(
            'UPDATE users SET name=$1, email=$2, address=$3, role=$4 WHERE id=$5 RETURNING id,name,email,address,role',
            [name ?? u.name, email ?? u.email, address ?? u.address, role ?? u.role, req.params.id]
        );
        res.json(up.rows[0]);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: 'Update user failed' });
    }
});

// Admin: delete user
app.delete('/api/admin/users/:id', auth, requireRole('ADMIN'), async (req, res) => {
    await client.query('DELETE FROM users WHERE id=$1', [req.params.id]);
    res.json({ ok: true });
});

// Admin: list stores
app.get('/api/admin/stores', auth, requireRole('ADMIN'), async (req, res) => {
    const result = await client.query(
        `SELECT s.id, s.name, s.email, s.address, s.rating, s.owner_id, u.name AS owner_name
     FROM stores s LEFT JOIN users u ON u.id = s.owner_id
     ORDER BY s.id DESC`
    );
    if(result.rows){
        res.status(200).json({
            'status':true,
            'result':result.rows
        });
    }
});

// Admin: create store (optional owner_id)
app.post('/api/admin/stores', auth, requireRole('ADMIN'), async (req, res) => {
    try {
        const { name, email = null, address, owner_id = null } = req.body;
        if (!name || !address)
            return res.status(400).json({ message: 'name and address required' });

        if (owner_id) {
            const own = await client.query("SELECT id FROM users WHERE id=$1 AND role='OWNER';", [
                owner_id,
            ]);
            if (!own.rowCount) return res.status(400).json({ message: 'Invalid owner_id' });
        }

        const ins = await client.query(
            'INSERT INTO stores(name,email,address,owner_id) VALUES ($1,$2,$3,$4) RETURNING *',
            [name, email, address, owner_id]
        );
        res.status(201).json(ins.rows[0]);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: 'Create store failed' });
    }
});

// Admin: update store
app.put('/api/admin/stores/:id', auth, requireRole('ADMIN'), async (req, res) => {
    try {
        const { name, email, address, owner_id } = req.body;

        if (owner_id !== undefined && owner_id !== null) {
            const own = await client.query("SELECT id FROM users WHERE id=$1 AND role='OWNER'", [
                owner_id,
            ]);
            if (!own.rowCount) return res.status(400).json({ message: 'Invalid owner_id' });
        }

        const cur = await client.query('SELECT * FROM stores WHERE id=$1', [req.params.id]);
        if (!cur.rowCount) return res.status(404).json({ message: 'Store not found' });
        const s = cur.rows[0];

        const up = await client.query(
            'UPDATE stores SET name=$1, email=$2, address=$3, owner_id=$4 WHERE id=$5 RETURNING *',
            [name ?? s.name, email ?? s.email, address ?? s.address, owner_id ?? s.owner_id, req.params.id]
        );
        res.json(up.rows[0]);
    } catch (e) {
        console.error(e);
        res.status(500).json({ message: 'Update store failed' });
    }
});

// Admin: delete store
app.delete('/api/admin/stores/:id', auth, requireRole('ADMIN'), async (req, res) => {
    await client.query('DELETE FROM stores WHERE id=$1', [req.params.id]);
    res.json({ ok: true });
});



app.listen(5000, () => {
    console.log("✅ Server started on port 5000");
});
